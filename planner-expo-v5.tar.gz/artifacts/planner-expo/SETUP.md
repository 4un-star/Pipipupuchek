# Учебный планировщик — Expo (React Native)

## Архитектура: полностью автономное приложение

```
Телефон
  ├── SQLite — все задачи, кэш оценок и пропусков
  ├── SecureStore (Android Keystore) — логин/пароль
  └── fetch → moodle.preco.ru
        ├── /login/token.php          → токен (официальный Web Services API)
        ├── /webservice/rest/server.php → курсы, оценки, календарь, задания
        └── /blocks/lkstudents/missedclass.php → пропущенные часы (HTML)
```

**Внешние зависимости:** только `moodle.preco.ru`. Никаких Replit, AWS, Google и других сторонних сервисов.

---

## Как работает синхронизация

| Данные | Метод | Надёжность |
|--------|-------|-----------|
| Курсы студента | Moodle Web Services API (токен) | ✅ Официальный, стабильный |
| Оценки | Moodle Web Services API | ✅ Официальный, стабильный |
| Задания / дедлайны | Moodle Web Services API (календарь) | ✅ Официальный, стабильный |
| Пропущенные часы | Прямой HTML-запрос (кастомный блок) | ⚠️ Кэш при ошибке |

React Native не имеет CORS-ограничений — телефон делает `fetch` напрямую на Moodle,  
без промежуточного сервера.

---

## Требования

- Node.js 18+
- Expo CLI: `npm install -g expo-cli eas-cli`
- Аккаунт на expo.dev (бесплатный, нужен только для сборки APK)

---

## Сборка APK (3 шага)

### 1. Установи зависимости
```bash
npm install
```

### 2. Войди в Expo
```bash
eas login
```

### 3. Собери APK
```bash
eas build --platform android --profile preview
```
Через 10–15 минут получишь ссылку на `.apk` файл — скачай и установи на телефон.

---

## Локальный запуск (для разработки)

```bash
npx expo start
```
Нажми `a` для Android эмулятора или отсканируй QR в приложении **Expo Go**.

---

## Структура проекта

```
src/
├── config.ts              ← Только MOODLE_BASE_URL и типы задач
├── theme.ts               ← Цвета и стили
├── db/
│   └── index.ts           ← SQLite: инициализация и CRUD
├── api/
│   └── moodle.ts          ← Прямые запросы к moodle.preco.ru (без бэкенда)
├── context/
│   └── AuthContext.tsx    ← Авторизация через Moodle token API
└── screens/
    ├── LoginScreen.tsx    ← Вход через Moodle
    ├── HomeScreen.tsx     ← Обзор, статистика и риски
    ├── TasksScreen.tsx    ← Список задач
    ├── CalendarScreen.tsx ← Календарь
    └── MoodleScreen.tsx   ← Синхронизация, оценки, пропуски
```

---

## Для диплома

**Единственная внешняя зависимость — `moodle.preco.ru`:**
- Данные хранятся на телефоне (SQLite + Android Keystore)
- При отсутствии интернета показываются кэшированные данные
- При обновлении Moodle — Web Services API остаётся совместимым (официальный стандарт)
- Если страница пропусков изменится — остальные функции продолжают работать нормально
