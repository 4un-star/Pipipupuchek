import React, { useState } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSQLiteContext } from "expo-sqlite";
import { useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

import { upsertMoodleTasks, getMoodleCache, setMoodleCache, getAllTasks } from "@/db";
import {
  syncMoodle,
  detectScheduleChanges,
  GradeBookEntry,
  CourseOverviewGrade,
  MissingAssignment,
  CalendarEvent,
  MoodleCourse,
} from "@/api/moodle";
import { useAuth } from "@/context/AuthContext";
import { colors, spacing, radius, fontSize, shadow } from "@/theme";
import {
  notifyScheduleChange,
  scheduleDeadlineNotifications,
} from "@/notifications";

// ─── Вспомогательные компоненты ───────────────────────────────────────────────

const MONTHS: Record<number, string> = {
  0:"Январь",1:"Февраль",2:"Март",3:"Апрель",
  4:"Май",5:"Июнь",6:"Июль",7:"Август",
  8:"Сентябрь",9:"Октябрь",10:"Ноябрь",11:"Декабрь",
};

function Section({
  icon, title, badge, children,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  badge?: number;
  children: React.ReactNode;
}) {
  return (
    <View style={[styles.card, shadow.card]}>
      <View style={styles.cardHeader}>
        <Ionicons name={icon} size={18} color={colors.primary} />
        <Text style={styles.cardTitle}>{title}</Text>
        {badge !== undefined && badge > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{badge}</Text>
          </View>
        )}
      </View>
      {children}
    </View>
  );
}

function gradeColor(g: number | null): string {
  if (g === null) return colors.textSecondary;
  if (g >= 5) return colors.success;
  if (g >= 4) return "#16a34a";
  if (g >= 3) return "#d97706";
  return colors.destructive;
}

function gradeLabel(g: number | null): string {
  return g === null ? "—" : String(g);
}

// ─── Главный экран ─────────────────────────────────────────────────────────────

export default function MoodleScreen() {
  const db = useSQLiteContext();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [isSyncing, setIsSyncing] = useState(false);

  // Читаем кэшированные данные
  const gradeBook: GradeBookEntry[] = JSON.parse(getMoodleCache(db, "gradeBook") ?? "[]");
  const courseOverview: CourseOverviewGrade[] = JSON.parse(getMoodleCache(db, "courseOverview") ?? "[]");
  const missedHours: Record<string, number> = JSON.parse(getMoodleCache(db, "missedHours") ?? "{}");
  const missingAssignments: MissingAssignment[] = JSON.parse(getMoodleCache(db, "missingAssignments") ?? "[]");
  const courses: MoodleCourse[] = JSON.parse(getMoodleCache(db, "courses") ?? "[]");
  const lastSyncAt = getMoodleCache(db, "lastSyncAt");
  const scheduleChanges: string[] = JSON.parse(getMoodleCache(db, "scheduleChanges") ?? "[]");

  const now = new Date();
  const currentMonthKey = `${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
  const thisMonthMissed = missedHours[currentMonthKey] ?? null;
  const totalMissed = Object.values(missedHours).reduce((a, b) => a + b, 0);

  // Группируем зачётную книжку по секциям
  const gradeBookBySection: Record<string, GradeBookEntry[]> = {};
  for (const e of gradeBook) {
    if (!gradeBookBySection[e.sectionLabel]) gradeBookBySection[e.sectionLabel] = [];
    gradeBookBySection[e.sectionLabel].push(e);
  }
  // Порядок секций
  const sectionOrder = [
    "Семестр 1","Семестр 2","Семестр 3","Семестр 4","Семестр 5","Семестр 6",
    "Курсовая","Практика","ВКР",
  ];
  const orderedSections = sectionOrder.filter(s => gradeBookBySection[s]?.length > 0);

  // ── Синхронизация ──────────────────────────────────────────────────────────

  const handleSync = async () => {
    if (!user?.username || !user?.password) {
      Alert.alert("Ошибка", "Необходимо войти в аккаунт заново");
      return;
    }
    setIsSyncing(true);
    try {
      const result = await syncMoodle(user.username, user.password);

      upsertMoodleTasks(db, result.tasks);

      setMoodleCache(db, "missedHours", JSON.stringify(result.missedHours));
      setMoodleCache(db, "gradeBook", JSON.stringify(result.gradeBook));
      setMoodleCache(db, "courseOverview", JSON.stringify(result.courseOverview));
      setMoodleCache(db, "missingAssignments", JSON.stringify(result.missingAssignments));
      setMoodleCache(db, "calendarEvents", JSON.stringify(result.calendarEvents));
      setMoodleCache(db, "courses", JSON.stringify(result.courses));
      setMoodleCache(db, "lastSyncAt", new Date().toISOString());

      // Изменения расписания
      const prevEventsRaw = getMoodleCache(db, "prevCalendarEvents");
      if (prevEventsRaw) {
        const prevEvents: CalendarEvent[] = JSON.parse(prevEventsRaw);
        const diff = detectScheduleChanges(prevEvents, result.calendarEvents);
        const changeStrings: string[] = [
          ...diff.added.map(e => `+ ${e.name}`),
          ...diff.removed.map(e => `- ${e.name}`),
        ];
        if (changeStrings.length > 0) {
          await notifyScheduleChange(changeStrings);
          setMoodleCache(db, "scheduleChanges", JSON.stringify(changeStrings));
        }
      }
      setMoodleCache(db, "prevCalendarEvents", JSON.stringify(result.calendarEvents));

      // Уведомления о дедлайнах
      const allTasks = getAllTasks(db);
      await scheduleDeadlineNotifications(allTasks);

      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["stats"] });
      queryClient.invalidateQueries({ queryKey: ["risks"] });

      const lines: string[] = [];
      if (result.courses.length > 0) lines.push(`✓ Курсов: ${result.courses.length}`);
      if (result.gradeBook.length > 0) lines.push(`✓ Зачётная книжка: ${result.gradeBook.length} записей`);
      else lines.push("○ Зачётная книжка не получена");
      if (Object.keys(result.missedHours).length > 0)
        lines.push(`✓ Пропуски: ${Object.keys(result.missedHours).length} мес.`);
      else lines.push("○ Пропуски не получены");
      if (result.tasks.length > 0) lines.push(`✓ Задач: ${result.tasks.length}`);
      if (result.apiError) lines.push(`⚠ ${result.apiError.slice(0, 80)}`);

      Alert.alert("Синхронизация завершена", lines.join("\n"));
    } catch (err: any) {
      Alert.alert("Ошибка синхронизации", err.message ?? "Проверьте подключение к интернету.");
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Рендер ────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>Moodle</Text>
        <Text style={styles.subheading}>moodle.preco.ru · прямое подключение</Text>

        {/* Баннер пропусков */}
        {thisMonthMissed !== null && (
          <View style={[styles.banner, thisMonthMissed >= 18 && styles.bannerDanger]}>
            <Ionicons
              name="alert-circle-outline" size={20}
              color={thisMonthMissed >= 18 ? colors.destructive : "#d97706"}
            />
            <View style={styles.bannerText}>
              <Text style={[styles.bannerHours, { color: thisMonthMissed >= 18 ? colors.destructive : "#d97706" }]}>
                {thisMonthMissed} ч. в {MONTHS[now.getMonth()].toLowerCase()}
              </Text>
              <Text style={styles.bannerSub}>
                {thisMonthMissed >= 20
                  ? `ВЫГОВОР — лимит 18 ч. превышен на ${thisMonthMissed - 18} ч.`
                  : thisMonthMissed >= 18
                  ? `Лимит превышен · до выговора ${20 - thisMonthMissed} ч.`
                  : `Лимит 18 ч./мес · осталось ${18 - thisMonthMissed} ч. · всего ${totalMissed} ч.`}
              </Text>
            </View>
          </View>
        )}

        {/* Изменения расписания */}
        {scheduleChanges.length > 0 && (
          <View style={styles.changesBanner}>
            <Ionicons name="calendar-outline" size={18} color="#7c3aed" />
            <View style={{ flex: 1 }}>
              <Text style={styles.changesTitle}>Изменения расписания ({scheduleChanges.length})</Text>
              {scheduleChanges.slice(0, 4).map((c, i) => (
                <Text key={i} style={styles.changesItem}>• {c}</Text>
              ))}
            </View>
          </View>
        )}

        {/* Синхронизация */}
        <Section icon="refresh-outline" title="Синхронизация">
          <Text style={styles.cardSub}>
            Загружает зачётную книжку, пропуски, задания напрямую из Moodle
          </Text>
          <View style={styles.accountRow}>
            <Ionicons name="person-circle-outline" size={20} color={colors.primary} />
            <Text style={styles.accountText}>{user?.username ?? "—"}</Text>
            <View style={styles.directBadge}>
              <Ionicons name="wifi-outline" size={12} color={colors.success} />
              <Text style={styles.directBadgeText}>прямое</Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.syncBtn, isSyncing && styles.btnDisabled]}
            onPress={handleSync} disabled={isSyncing} activeOpacity={0.8}
          >
            {isSyncing ? (
              <>
                <ActivityIndicator color={colors.white} size="small" />
                <Text style={styles.syncBtnText}>Синхронизация…</Text>
              </>
            ) : (
              <>
                <Ionicons name="refresh-outline" size={18} color={colors.white} />
                <Text style={styles.syncBtnText}>Синхронизировать с Moodle</Text>
              </>
            )}
          </TouchableOpacity>
          {lastSyncAt && (
            <Text style={styles.lastSync}>
              Последняя: {format(new Date(lastSyncAt), "d MMMM, HH:mm", { locale: ru })}
            </Text>
          )}
        </Section>

        {/* Курсы */}
        <Section icon="library-outline" title="Активные курсы" badge={courses.length}>
          {courses.length === 0 ? (
            <Text style={styles.noData}>Нет данных — нажмите «Синхронизировать»</Text>
          ) : (
            <View style={styles.courseList}>
              {courses.map((course) => (
                <View key={course.id} style={styles.courseRow}>
                  <View style={styles.courseIcon}>
                    <Ionicons name="book-outline" size={14} color={colors.primary} />
                  </View>
                  <Text style={styles.courseName} numberOfLines={2}>{course.name}</Text>
                </View>
              ))}
            </View>
          )}
        </Section>

        {/* Обзор текущих оценок */}
        {courseOverview.length > 0 && (
          <Section icon="stats-chart-outline" title="Оценки по текущим курсам" badge={courseOverview.length}>
            <View style={styles.courseList}>
              {courseOverview.map((cog, idx) => (
                <View key={idx} style={styles.gradeRow}>
                  <Text style={styles.gradeItem} numberOfLines={2}>{cog.courseName}</Text>
                  <View style={[styles.gradeBadge, { backgroundColor: gradeColor(cog.grade) + "20" }]}>
                    <Text style={[styles.gradeValue, { color: gradeColor(cog.grade) }]}>
                      {cog.grade ?? "—"}{cog.percent !== null ? ` (${cog.percent}%)` : ""}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </Section>
        )}

        {/* Электронная зачётная книжка */}
        <Section icon="school-outline" title="Зачётная книжка" badge={gradeBook.length}>
          {orderedSections.length === 0 ? (
            <Text style={styles.noData}>Нет данных — нажмите «Синхронизировать»</Text>
          ) : (
            orderedSections.map((section) => (
              <View key={section} style={styles.semesterBlock}>
                <Text style={styles.semesterTitle}>{section}</Text>
                {gradeBookBySection[section].map((e, idx) => (
                  <View key={idx} style={styles.gradeRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.gradeItem} numberOfLines={2}>{e.discipline}</Text>
                      <Text style={styles.gradeSubtext}>
                        {e.controlForm}{e.hours > 0 ? ` · ${e.hours}ч` : ""}
                        {e.gradeDate ? ` · ${e.gradeDate}` : ""}
                      </Text>
                    </View>
                    <View style={[styles.gradeBadge, { backgroundColor: gradeColor(e.grade) + "20" }]}>
                      <Text style={[styles.gradeValue, { color: gradeColor(e.grade) }]}>
                        {gradeLabel(e.grade)}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            ))
          )}
        </Section>

        {/* Несданные работы */}
        <Section
          icon="document-text-outline"
          title="Несданные работы"
          badge={missingAssignments.length || undefined}
        >
          {missingAssignments.length === 0 ? (
            <Text style={styles.noData}>
              {gradeBook.length > 0
                ? "Нет просроченных заданий — отлично!"
                : "Нет данных — нажмите «Синхронизировать»"}
            </Text>
          ) : (
            missingAssignments
              .sort((a, b) => b.daysOverdue - a.daysOverdue)
              .map((a, i) => (
                <View key={i} style={styles.missingRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.missingName} numberOfLines={1}>{a.name}</Text>
                    <Text style={styles.missingCourse}>{a.courseName}</Text>
                  </View>
                  <View style={[styles.overdueBadge, a.daysOverdue >= 7 && styles.overdueBadgeDanger]}>
                    <Text style={[styles.overdueText, a.daysOverdue >= 7 && styles.overdueTextDanger]}>
                      +{a.daysOverdue} дн.
                    </Text>
                  </View>
                </View>
              ))
          )}
        </Section>

        {/* Пропуски */}
        <Section icon="time-outline" title="Пропущенные часы по месяцам">
          {Object.keys(missedHours).length === 0 ? (
            <Text style={styles.noData}>Нет данных — нажмите «Синхронизировать»</Text>
          ) : (
            <View style={styles.monthList}>
              {Object.entries(missedHours).map(([month, hours]) => {
                const isCurrent = month === currentMonthKey;
                const isDangerous = Number(hours) > 8;
                return (
                  <View key={month} style={[styles.monthRow, isCurrent && styles.monthRowCurrent]}>
                    <View style={styles.monthNameRow}>
                      <Text style={[styles.monthName, isCurrent && { color: colors.primary }]}>{month}</Text>
                      {isCurrent && (
                        <View style={styles.currentBadge}>
                          <Text style={styles.currentBadgeText}>сейчас</Text>
                        </View>
                      )}
                    </View>
                    <View style={[styles.hoursBadge, isDangerous && styles.hoursBadgeDanger]}>
                      <Text style={[styles.hoursText, isDangerous && styles.hoursTextDanger]}>
                        {hours} ч. / {Math.round(Number(hours) / 2)} пар
                      </Text>
                    </View>
                  </View>
                );
              })}
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Итого</Text>
                <View style={[styles.hoursBadge, totalMissed >= 36 && styles.hoursBadgeDanger]}>
                  <Text style={[styles.hoursText, totalMissed >= 36 && styles.hoursTextDanger]}>
                    {totalMissed} ч. / {Math.round(totalMissed / 2)} пар
                  </Text>
                </View>
              </View>
            </View>
          )}
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Стили ────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, gap: spacing.md },
  heading: { fontSize: fontSize.xxl, fontWeight: "600", color: colors.text },
  subheading: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: -spacing.sm },
  banner: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, padding: spacing.md, borderRadius: radius.md, backgroundColor: "#fff8e7", borderWidth: 1, borderColor: "#f59e0b50" },
  bannerDanger: { backgroundColor: colors.destructiveLight, borderColor: colors.destructive + "50" },
  bannerText: { flex: 1 },
  bannerHours: { fontSize: fontSize.md, fontWeight: "700" },
  bannerSub: { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 2 },
  changesBanner: { flexDirection: "row", gap: spacing.sm, padding: spacing.md, borderRadius: radius.md, backgroundColor: "#f5f3ff", borderWidth: 1, borderColor: "#7c3aed30" },
  changesTitle: { fontSize: fontSize.sm, fontWeight: "600", color: "#7c3aed", marginBottom: 4 },
  changesItem: { fontSize: fontSize.xs, color: colors.textSecondary },
  card: { backgroundColor: colors.card, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.md, borderWidth: 1, borderColor: colors.border },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: spacing.xs },
  cardTitle: { fontSize: fontSize.lg, fontWeight: "600", color: colors.text, flex: 1 },
  badge: { backgroundColor: colors.primary, borderRadius: radius.full, minWidth: 22, height: 22, justifyContent: "center", alignItems: "center", paddingHorizontal: 6 },
  badgeText: { fontSize: 11, fontWeight: "700", color: colors.white },
  cardSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: -spacing.sm },
  accountRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm, paddingHorizontal: spacing.md, backgroundColor: colors.muted, borderRadius: radius.sm },
  accountText: { fontSize: fontSize.md, color: colors.text, fontWeight: "500", flex: 1 },
  directBadge: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.success + "20", borderRadius: radius.sm, paddingHorizontal: 6, paddingVertical: 2 },
  directBadgeText: { fontSize: 11, color: colors.success, fontWeight: "600" },
  syncBtn: { backgroundColor: colors.primary, borderRadius: radius.sm, paddingVertical: 14, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: spacing.sm },
  btnDisabled: { opacity: 0.5 },
  syncBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: "600" },
  lastSync: { fontSize: fontSize.xs, color: colors.textSecondary, textAlign: "center" },
  noData: { fontSize: fontSize.sm, color: colors.textSecondary },
  courseList: { gap: spacing.xs },
  courseRow: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: colors.border },
  courseIcon: { width: 24, height: 24, borderRadius: radius.sm, backgroundColor: colors.primaryLight, justifyContent: "center", alignItems: "center", marginTop: 1 },
  courseName: { flex: 1, fontSize: fontSize.sm, color: colors.text, lineHeight: 20 },
  semesterBlock: { gap: spacing.xs, marginBottom: spacing.sm },
  semesterTitle: { fontSize: fontSize.sm, fontWeight: "700", color: colors.primary, paddingBottom: 4, borderBottomWidth: 1, borderBottomColor: colors.primaryLight },
  gradeRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: colors.border },
  gradeItem: { flex: 1, fontSize: fontSize.xs, color: colors.text, marginRight: spacing.sm },
  gradeSubtext: { fontSize: 10, color: colors.textSecondary, marginTop: 1 },
  gradeBadge: { borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: 3, minWidth: 32, alignItems: "center" },
  gradeValue: { fontSize: fontSize.xs, fontWeight: "700" },
  missingRow: { flexDirection: "row", alignItems: "center", paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.sm },
  missingName: { fontSize: fontSize.sm, color: colors.text, fontWeight: "500" },
  missingCourse: { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 1 },
  overdueBadge: { backgroundColor: "#fef9c3", borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: 4 },
  overdueBadgeDanger: { backgroundColor: colors.destructiveLight },
  overdueText: { fontSize: fontSize.xs, fontWeight: "700", color: "#a16207" },
  overdueTextDanger: { color: colors.destructive },
  monthList: { gap: spacing.xs },
  monthRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: colors.border },
  monthRowCurrent: { backgroundColor: colors.primaryLight + "40", borderRadius: radius.sm, paddingHorizontal: spacing.xs },
  monthNameRow: { flexDirection: "row", alignItems: "center", gap: spacing.xs, flex: 1 },
  monthName: { fontSize: fontSize.sm, color: colors.text },
  currentBadge: { backgroundColor: colors.primary, borderRadius: radius.full, paddingHorizontal: 6, paddingVertical: 1 },
  currentBadgeText: { fontSize: 10, color: colors.white, fontWeight: "600" },
  hoursBadge: { backgroundColor: "#f0fdf4", borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: 3 },
  hoursBadgeDanger: { backgroundColor: colors.destructiveLight },
  hoursText: { fontSize: fontSize.xs, fontWeight: "600", color: colors.success },
  hoursTextDanger: { color: colors.destructive },
  totalRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: spacing.sm },
  totalLabel: { fontSize: fontSize.sm, fontWeight: "700", color: colors.text },
});
