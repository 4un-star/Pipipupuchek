/**
 * moodle.ts — полный парсинг moodle.preco.ru
 *
 * Все парсеры протестированы на реальном аккаунте.
 *
 * Источники данных:
 *  • Логин      → POST /login/index.php  (ручной обход testsession)
 *  • Зачётная книжка → /blocks/lkstudents/marks.php
 *      9 таблиц class="generaltable":
 *      [0-5] Семестры 1-6  (дисциплина|форма|часы|оценка|дата|преподаватель)
 *      [6]   Курсовые работы (семестр|дисциплина|тема|оценка|дата|преподаватель)
 *      [7]   Практики (курс/сем|вид|место|часы|оценка|дата|руководитель)
 *      [8]   ВКР
 *  • Обзор оценок  → /grade/report/overview/index.php  (текущие курсы)
 *  • Пропуски      → /blocks/lkstudents/missedclass.php
 *  • Задания       → /mod/assign/index.php?id=COURSE_ID
 *  • Курсы (AJAX)  → /lib/ajax/service.php (sesskey из /my/)
 *  • Календарь     → /calendar/view.php?view=upcoming
 */

import { MOODLE_BASE_URL } from "@/config";
import { Task } from "@/db";

// ─── Типы ────────────────────────────────────────────────────────────────────

/** Запись из электронной зачётной книжки (marks.php) */
export interface GradeBookEntry {
  /** 1-6 для семестров, 7=курсовая, 8=практика, 9=ВКР */
  semester: number;
  /** Человекочитаемый тип: "Семестр 1", "Курсовая", "Практика", "ВКР" */
  sectionLabel: string;
  discipline: string;
  /** "Экзамен" | "Дифференцированный зачет" | "Курсовая работа" | "Квалификационный экзамен" | ... */
  controlForm: string;
  hours: number;
  grade: number | null;        // null = не сдано / нет оценки
  gradeDate: string | null;    // "18.12.2023" или null
  teacher: string;
  /** Тема (только для курсовых) */
  topic?: string;
  /** Место проведения (только для практик) */
  place?: string;
}

/** Итоговая оценка текущего курса из обзора оценок */
export interface CourseOverviewGrade {
  courseName: string;
  grade: number | null;
  percent: number | null;
}

export interface MissingAssignment {
  courseId: number;
  courseName: string;
  name: string;
  dueDate: string;
  daysOverdue: number;
}

export interface CalendarEvent {
  id: number;
  name: string;
  timestart: number;
  eventtype: string;
  courseName?: string;
}

export interface MoodleCourse {
  id: number;
  name: string;
  shortname: string;
}

/** Запись о риске для "ленивого студента" */
export interface RiskItem {
  level: "critical" | "high" | "medium" | "low";
  category: "grades" | "absences" | "assignments" | "practice";
  message: string;
  detail?: string;
}

export interface MoodleSyncResult {
  tasks: Task[];
  missedHours: Record<string, number>;
  /** Вся зачётная книжка: все семестры, курсовые, практики */
  gradeBook: GradeBookEntry[];
  /** Текущие курсы с итоговой оценкой из обзора */
  courseOverview: CourseOverviewGrade[];
  missingAssignments: MissingAssignment[];
  calendarEvents: CalendarEvent[];
  courses: MoodleCourse[];
  /** Итоговый список рисков для экрана "Статус" */
  risks: RiskItem[];
  method: "scraping" | "none";
  apiError?: string;
}

// ─── Константы ───────────────────────────────────────────────────────────────

const UA = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36";

const MONTH_KEY_TO_NAME: Record<string, string> = {
  "январ": "Январь", "феврал": "Февраль", "март": "Март",
  "апрел": "Апрель", "май": "Май", "июн": "Июнь",
  "июл": "Июль", "август": "Август", "сентябр": "Сентябрь",
  "октябр": "Октябрь", "ноябр": "Ноябрь", "декабр": "Декабрь",
};

export const MONTHS_RU_NAMES = [
  "Январь","Февраль","Март","Апрель","Май","Июнь",
  "Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь",
];

const MONTH_PARSE_MAP: Record<string, number> = {
  "январ": 0, "феврал": 1, "март": 2, "апрел": 3, "ма": 4,
  "июн": 5, "июл": 6, "август": 7, "сентябр": 8,
  "октябр": 9, "ноябр": 10, "декабр": 11,
};

const SEMESTER_LABELS = [
  "Семестр 1","Семестр 2","Семестр 3",
  "Семестр 4","Семестр 5","Семестр 6",
];

// ─── Утилиты ─────────────────────────────────────────────────────────────────

function stripTags(html: string): string {
  return html
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#\d+;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function reqHeaders(cookie: string): Record<string, string> {
  return { Cookie: cookie, "User-Agent": UA };
}

async function fetchPage(url: string, cookie: string): Promise<string> {
  const res = await fetch(url, { headers: reqHeaders(cookie) });
  return res.text();
}

function mergeCookies(existing: string, incoming: string | null): string {
  if (!incoming) return existing;
  const map: Record<string, string> = {};
  for (const part of (existing + "; " + incoming).split(/;\s*/)) {
    const eq = part.indexOf("=");
    if (eq < 0) continue;
    const k = part.slice(0, eq).trim();
    const v = part.slice(eq + 1).split(";")[0].trim();
    const skip = ["path", "domain", "expires", "samesite", "secure", "httponly"];
    if (k && !skip.includes(k.toLowerCase())) map[k] = v;
  }
  return Object.entries(map).map(([k, v]) => `${k}=${v}`).join("; ");
}

function parseGrade(raw: string): number | null {
  const m = raw.match(/^(\d+)/);
  return m ? parseInt(m[1], 10) : null;
}

function parseDate(raw: string): string | null {
  return /\d{2}\.\d{2}\.\d{4}/.test(raw) ? raw.trim() : null;
}

/** Извлекает все строки таблицы (пропускает заголовок) */
function tableRows(tableHtml: string): string[][] {
  const rows: string[][] = [];
  const rowRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  let row: RegExpExecArray | null;
  let first = true;
  while ((row = rowRe.exec(tableHtml)) !== null) {
    if (first) { first = false; continue; } // пропускаем заголовок
    const cells: string[] = [];
    const cellRe = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
    let cell: RegExpExecArray | null;
    while ((cell = cellRe.exec(row[1])) !== null) {
      cells.push(stripTags(cell[1]).trim());
    }
    if (cells.length >= 2 && cells[0].length > 0) rows.push(cells);
  }
  return rows;
}

// ─── Логин ────────────────────────────────────────────────────────────────────

/**
 * Вход через HTML-форму, ручная цепочка редиректов Moodle:
 *   GET → POST(redirect:manual) → follow testsession → follow /my/
 */
async function loginViaWebForm(username: string, password: string): Promise<string> {
  let p1: Response;
  try {
    p1 = await fetch(`${MOODLE_BASE_URL}/login/index.php`, {
      headers: { "User-Agent": UA }, redirect: "follow",
    });
  } catch (e: any) {
    throw new Error(`Нет связи с moodle.preco.ru: ${e?.message ?? e}`);
  }

  const html1 = await p1.text();
  let cookie = p1.headers.get("set-cookie") ?? "";
  const ltMatch = html1.match(/name="logintoken"[^>]*value="([^"]+)"/);
  const logintoken = ltMatch?.[1] ?? "";

  const form = new URLSearchParams({ username, password, logintoken, anchor: "" });
  let p2: Response;
  try {
    p2 = await fetch(`${MOODLE_BASE_URL}/login/index.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie, "User-Agent": UA,
        "Origin": MOODLE_BASE_URL,
        "Referer": `${MOODLE_BASE_URL}/login/index.php`,
      },
      body: form.toString(),
      redirect: "manual",
    });
  } catch (e: any) {
    throw new Error(`Ошибка при отправке формы входа: ${e?.message ?? e}`);
  }

  cookie = mergeCookies(cookie, p2.headers.get("set-cookie"));
  const loc2 = p2.headers.get("location") ?? "";
  if (!loc2) throw new Error("invalid_credentials");

  const url3 = loc2.startsWith("http") ? loc2 : `${MOODLE_BASE_URL}${loc2}`;
  const p3 = await fetch(url3, { headers: reqHeaders(cookie), redirect: "manual" });
  cookie = mergeCookies(cookie, p3.headers.get("set-cookie"));
  const loc3 = p3.headers.get("location") ?? "";

  if (!loc3) {
    if (url3.includes("/login/")) throw new Error("invalid_credentials");
    return cookie;
  }

  const url4 = loc3.startsWith("http") ? loc3 : `${MOODLE_BASE_URL}${loc3}`;
  const p4 = await fetch(url4, { headers: reqHeaders(cookie), redirect: "follow" });
  cookie = mergeCookies(cookie, p4.headers.get("set-cookie"));
  const finalUrl = p4.url ?? url4;
  if (finalUrl.includes("/login/")) throw new Error("invalid_credentials");
  return cookie;
}

export async function validateMoodleLogin(
  username: string,
  password: string
): Promise<boolean> {
  try {
    await loginViaWebForm(username, password);
    return true;
  } catch (e: any) {
    if (e.message === "invalid_credentials") return false;
    throw e;
  }
}

// ─── sesskey и курсы (AJAX) ───────────────────────────────────────────────────

async function getSesskey(cookie: string): Promise<string> {
  const html = await fetchPage(`${MOODLE_BASE_URL}/my/`, cookie);
  return (html.match(/"sesskey":"([^"]+)"/))?.[1] ?? "";
}

async function fetchCourses(cookie: string, sesskey: string): Promise<MoodleCourse[]> {
  const body = JSON.stringify([{
    index: 0,
    methodname: "core_course_get_enrolled_courses_by_timeline_classification",
    args: { offset: 0, limit: 50, classification: "inprogress", sort: "fullname" },
  }]);
  const res = await fetch(
    `${MOODLE_BASE_URL}/lib/ajax/service.php?sesskey=${sesskey}&info=courses`,
    { method: "POST", headers: { ...reqHeaders(cookie), "Content-Type": "application/json" }, body }
  );
  const json: any = await res.json();
  return (json?.[0]?.data?.courses ?? []).map((c: any) => ({
    id: Number(c.id), name: String(c.fullname ?? ""), shortname: String(c.shortname ?? ""),
  }));
}

// ─── Зачётная книжка (marks.php) ─────────────────────────────────────────────

/**
 * Парсит /blocks/lkstudents/marks.php — электронная зачётная книжка.
 *
 * Структура: 9 таблиц class="generaltable" в порядке появления:
 *   [0] Семестр 1  ... [5] Семестр 6
 *   [6] Курсовые работы
 *   [7] Практики
 *   [8] ВКР
 *
 * Строки семестров: [дисциплина, форма_контроля, часы, оценка, дата, преподаватель]
 * Строки курсовых:  [семестр, дисциплина, тема, оценка, дата, преподаватель]
 * Строки практик:   [курс/сем, вид, место, часы, оценка, дата, руководитель]
 * Строки ВКР:       [тема, оценка, дата_защиты, руководитель]
 */
function parseGradeBookHtml(html: string): GradeBookEntry[] {
  const entries: GradeBookEntry[] = [];

  // Извлекаем все таблицы class="generaltable"
  const tableRe = /<table[^>]*class="[^"]*generaltable[^"]*"[^>]*>([\s\S]*?)<\/table>/gi;
  const tables: string[] = [];
  let tm: RegExpExecArray | null;
  while ((tm = tableRe.exec(html)) !== null) tables.push(tm[0]);

  // Таблицы 0-5: семестры
  for (let s = 0; s < 6 && s < tables.length; s++) {
    const rows = tableRows(tables[s]);
    for (const cells of rows) {
      if (cells.length < 4) continue;
      const discipline = cells[0];
      // Пропускаем строки-заголовки
      if (
        discipline.includes("Наименование") ||
        discipline.includes("Форма контроля") ||
        discipline.length < 2
      ) continue;

      const controlForm = cells[1] ?? "";
      const hours = parseInt(cells[2] ?? "0", 10) || 0;
      const gradeRaw = cells[3] ?? "";
      const dateRaw = cells[4] ?? "";
      const teacher = cells[5] ?? "";

      entries.push({
        semester: s + 1,
        sectionLabel: SEMESTER_LABELS[s],
        discipline,
        controlForm,
        hours,
        grade: parseGrade(gradeRaw),
        gradeDate: parseDate(dateRaw),
        teacher,
      });
    }
  }

  // Таблица 6: курсовые работы
  if (tables.length > 6) {
    const rows = tableRows(tables[6]);
    for (const cells of rows) {
      if (cells.length < 4) continue;
      // [семестр, дисциплина, тема, оценка, дата, преподаватель]
      const semesterLabel = cells[0]; // "4 семестр"
      const discipline = cells[1] ?? "";
      const topic = cells[2] ?? "";
      const gradeRaw = cells[3] ?? "";
      const dateRaw = cells[4] ?? "";
      const teacher = cells[5] ?? "";
      if (discipline.length < 2) continue;

      const semNum = parseInt(semesterLabel.match(/\d/)?.[0] ?? "0", 10);
      entries.push({
        semester: semNum || 7,
        sectionLabel: "Курсовая",
        discipline,
        controlForm: "Курсовая работа",
        hours: 0,
        grade: parseGrade(gradeRaw),
        gradeDate: parseDate(dateRaw),
        teacher,
        topic,
      });
    }
  }

  // Таблица 7: практики
  if (tables.length > 7) {
    const rows = tableRows(tables[7]);
    for (const cells of rows) {
      if (cells.length < 5) continue;
      // [курс/сем, вид_практики, место, часы, оценка, дата, руководитель]
      const courseSem = cells[0]; // "2 курс 4 семестр"
      const type = cells[1] ?? "";  // "Производственная практика ПМ.11"
      const place = cells[2] ?? "";
      const hours = parseInt(cells[3] ?? "0", 10) || 0;
      const gradeRaw = cells[4] ?? "";
      const dateRaw = cells[5] ?? "";
      const teacher = cells[6] ?? "";
      if (type.length < 2) continue;

      const semNum = parseInt(courseSem.match(/(\d+)\s*семестр/)?.[1] ?? "0", 10);
      entries.push({
        semester: semNum || 8,
        sectionLabel: "Практика",
        discipline: type,
        controlForm: type.includes("Производ") ? "Производственная практика" : "Учебная практика",
        hours,
        grade: parseGrade(gradeRaw),
        gradeDate: parseDate(dateRaw),
        teacher,
        place,
      });
    }
  }

  // Таблица 8: ВКР
  if (tables.length > 8) {
    const rows = tableRows(tables[8]);
    for (const cells of rows) {
      if (cells.length < 2) continue;
      const topic = cells[0];
      if (topic === "-" || topic.length < 2) continue;
      const gradeRaw = cells[1] ?? "";
      const dateRaw = cells[2] ?? "";
      const teacher = cells[3] ?? "";
      entries.push({
        semester: 9,
        sectionLabel: "ВКР",
        discipline: "Выпускная квалификационная работа",
        controlForm: "ВКР",
        hours: 0,
        grade: parseGrade(gradeRaw),
        gradeDate: parseDate(dateRaw),
        teacher,
        topic,
      });
    }
  }

  return entries;
}

// ─── Обзор оценок текущих курсов ─────────────────────────────────────────────

/**
 * Парсит /grade/report/overview/index.php
 * Таблица: [название курса, оценка(%)]. Формат оценки: "3 (70,16 %)" или "-"
 */
function parseGradeOverview(html: string): CourseOverviewGrade[] {
  const result: CourseOverviewGrade[] = [];
  const rowRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  let row: RegExpExecArray | null;
  let first = true;
  while ((row = rowRe.exec(html)) !== null) {
    if (first) { first = false; continue; }
    const cells: string[] = [];
    const cellRe = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
    let cell: RegExpExecArray | null;
    while ((cell = cellRe.exec(row[1])) !== null) {
      cells.push(stripTags(cell[1]).trim());
    }
    if (cells.length < 2) continue;
    const courseName = cells[0];
    if (!courseName || courseName.length < 3) continue;
    const gradeCell = cells[1];
    // "3 (70,16 %)" → grade=3, percent=70.16
    const m = gradeCell.match(/^(\d+)\s*\((\d+[.,]\d+)\s*%\)/);
    if (m) {
      result.push({
        courseName,
        grade: parseInt(m[1], 10),
        percent: parseFloat(m[2].replace(",", ".")),
      });
    } else if (gradeCell === "-") {
      result.push({ courseName, grade: null, percent: null });
    }
  }
  return result;
}

// ─── Пропущенные часы ────────────────────────────────────────────────────────

function parseMissedHoursHtml(html: string): Record<string, number> {
  const result: Record<string, number> = {};
  const text = html.replace(/<[^>]+>/g, " ").replace(/&[a-zA-Z#0-9]+;/g, " ").replace(/\s+/g, " ");
  const MONTH_PREFIX_RE = /^(Январ|Феврал|Март|Апрел|Май|Июн|Июл|Август|Сентябр|Октябр|Ноябр|Декабр)/i;
  const tokens = text.split(/\s+/);
  let currentYear = String(new Date().getFullYear());
  let currentMonthName: string | null = null;
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (/^20\d{2}$/.test(t)) { currentYear = t; continue; }
    const mTest = MONTH_PREFIX_RE.exec(t);
    if (mTest) {
      const raw = t.toLowerCase();
      const key = Object.keys(MONTH_KEY_TO_NAME).find((k) => raw.startsWith(k));
      if (key) currentMonthName = `${MONTH_KEY_TO_NAME[key]} ${currentYear}`;
      continue;
    }
    if (t.toLowerCase() === "всего" && currentMonthName) {
      const next = tokens[i + 1];
      if (next && /^\d+$/.test(next)) {
        const hours = parseInt(next, 10);
        if (hours > 0 && hours <= 400 && !(currentMonthName in result)) {
          result[currentMonthName] = hours;
        }
        i += 1;
      }
    }
  }
  return result;
}

// ─── Задания ─────────────────────────────────────────────────────────────────

function parseAssignments(
  html: string, courseId: number, courseName: string
): { tasks: Task[]; missing: MissingAssignment[] } {
  const tasks: Task[] = [];
  const missing: MissingAssignment[] = [];
  const now = Date.now();
  const rowRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  let row: RegExpExecArray | null;
  while ((row = rowRe.exec(html)) !== null) {
    const rowHtml = row[1];
    const dateRu = rowHtml.match(
      /(\d{1,2})\s+(январ\w*|феврал\w*|март\w*|апрел\w*|ма[йя]\w*|июн\w*|июл\w*|август\w*|сентябр\w*|октябр\w*|ноябр\w*|декабр\w*)\s+(\d{4})/i
    );
    const dateDot = rowHtml.match(/(\d{2})\.(\d{2})\.(\d{4})/);
    let dueDate: Date | null = null;
    if (dateRu) {
      const raw = dateRu[2].toLowerCase().slice(0, 7);
      const mon = Object.keys(MONTH_PARSE_MAP).find((k) => raw.startsWith(k));
      if (mon !== undefined) {
        dueDate = new Date(parseInt(dateRu[3], 10), MONTH_PARSE_MAP[mon], parseInt(dateRu[1], 10));
      }
    } else if (dateDot) {
      dueDate = new Date(parseInt(dateDot[3], 10), parseInt(dateDot[2], 10) - 1, parseInt(dateDot[1], 10));
    }
    if (!dueDate || isNaN(dueDate.getTime())) continue;
    const nameMatch = rowHtml.match(/<a[^>]*>([^<]{3,120})<\/a>/);
    const name = nameMatch ? stripTags(nameMatch[1]).trim() : "";
    if (!name) continue;
    const id = `moodle_assign_${courseId}_${name.slice(0, 20).replace(/\s/g, "_")}_${dueDate.getTime()}`;
    if (dueDate.getTime() > now) {
      tasks.push({
        id, title: name, description: null, date: dueDate.toISOString(),
        type: "deadline", subject: courseName, completed: false,
        notificationDays: 1, source: "moodle", createdAt: new Date().toISOString(),
      });
    } else {
      const daysOverdue = Math.floor((now - dueDate.getTime()) / 86_400_000);
      if (daysOverdue <= 60) {
        missing.push({ courseId, courseName, name, dueDate: dueDate.toISOString(), daysOverdue });
      }
    }
  }
  return { tasks, missing };
}

// ─── Календарь ───────────────────────────────────────────────────────────────

function parseCalendarHtml(html: string): { tasks: Task[]; events: CalendarEvent[] } {
  const tasks: Task[] = [];
  const events: CalendarEvent[] = [];
  const now = Date.now();
  const seenIds = new Set<number>();
  const evRe = /data-event-id="(\d+)"[\s\S]{0,800}?data-starttime="(\d+)"[\s\S]{0,400}?<(?:a|h3)[^>]*>\s*([^<]{3,120})\s*<\/(?:a|h3)>/gi;
  let m: RegExpExecArray | null;
  while ((m = evRe.exec(html)) !== null) {
    const id = parseInt(m[1], 10);
    const timestart = parseInt(m[2], 10);
    const name = stripTags(m[3]).trim();
    if (!name || seenIds.has(id)) continue;
    seenIds.add(id);
    events.push({ id, name, timestart, eventtype: "site" });
    if (timestart * 1000 > now) tasks.push(makeEventTask(id, name, timestart, ""));
  }
  if (events.length === 0) {
    const blockRe = /<(?:div|li)[^>]*class="[^"]*event[^"]*"[^>]*>([\s\S]{0,1000}?)<\/(?:div|li)>/gi;
    let block: RegExpExecArray | null;
    let idx = 0;
    while ((block = blockRe.exec(html)) !== null) {
      const blockHtml = block[1];
      const nameM = blockHtml.match(/<a[^>]*>([^<]{3,120})<\/a>/);
      if (!nameM) continue;
      const name = stripTags(nameM[1]).trim();
      if (!name) continue;
      const tsM = blockHtml.match(/data-starttime="(\d+)"/);
      const timestart = tsM ? parseInt(tsM[1], 10) : Math.floor(now / 1000) + 86_400 * (idx + 1);
      const id = 900_000 + idx;
      events.push({ id, name, timestart, eventtype: "site" });
      if (timestart * 1000 > now) tasks.push(makeEventTask(id, name, timestart, ""));
      idx++;
      if (idx > 30) break;
    }
  }
  return { tasks, events };
}

function makeEventTask(id: number, name: string, timestart: number, courseName: string): Task {
  const date = new Date(timestart * 1000);
  const lname = name.toLowerCase();
  let type: Task["type"] = "homework";
  if (lname.includes("экзамен") || lname.includes("зачёт") || lname.includes("зачет")) type = "exam";
  else if (lname.includes("сессия")) type = "session";
  else if (lname.includes("дедлайн") || lname.includes("сдача") || lname.includes("задание")) type = "deadline";
  return {
    id: `moodle_ev_${id}`, title: name, description: null, date: date.toISOString(),
    type, subject: courseName || "Moodle", completed: false,
    notificationDays: type === "exam" ? 3 : 1, source: "moodle",
    createdAt: new Date().toISOString(),
  };
}

// ─── Вычисление рисков ────────────────────────────────────────────────────────

/**
 * Генерирует список рисков для "ленивого студента".
 * Источники: зачётная книжка, обзор оценок, пропуски, задания.
 */
export function computeRisks(
  gradeBook: GradeBookEntry[],
  courseOverview: CourseOverviewGrade[],
  missedHours: Record<string, number>,
  missingAssignments: MissingAssignment[]
): RiskItem[] {
  const risks: RiskItem[] = [];

  // 1. ПРОПУСКИ — сортируем по последним месяцам
  const missedEntries = Object.entries(missedHours)
    .map(([month, hours]) => ({ month, hours }))
    .sort((a, b) => {
      const [am, ay] = a.month.split(" ");
      const [bm, by] = b.month.split(" ");
      if (ay !== by) return parseInt(by, 10) - parseInt(ay, 10);
      return MONTHS_RU_NAMES.indexOf(bm) - MONTHS_RU_NAMES.indexOf(am);
    });

  const totalHours = missedEntries.reduce((s, e) => s + e.hours, 0);
  if (totalHours >= 150) {
    risks.push({
      level: "critical", category: "absences",
      message: `Критическое количество пропусков: ${totalHours} ч за всё время`,
      detail: missedEntries.slice(0, 3).map(e => `${e.month}: ${e.hours}ч`).join(", "),
    });
  } else if (totalHours >= 60) {
    risks.push({
      level: "high", category: "absences",
      message: `Высокое количество пропусков: ${totalHours} ч`,
      detail: missedEntries.slice(0, 3).map(e => `${e.month}: ${e.hours}ч`).join(", "),
    });
  }
  // Последний месяц с пропусками
  const lastMonth = missedEntries[0];
  if (lastMonth && lastMonth.hours >= 20) {
    risks.push({
      level: lastMonth.hours >= 40 ? "high" : "medium",
      category: "absences",
      message: `${lastMonth.month}: ${lastMonth.hours}ч пропусков`,
    });
  }

  // 2. ТЕКУЩИЕ ОЦЕНКИ (обзор) — ниже 60% или нет оценки
  for (const cog of courseOverview) {
    if (cog.grade !== null && cog.grade <= 2) {
      risks.push({
        level: "critical", category: "grades",
        message: `Неудовлетворительно по: ${cog.courseName.slice(0, 50)}`,
        detail: `Оценка: ${cog.grade} (${cog.percent ?? "?"}%)`,
      });
    } else if (cog.percent !== null && cog.percent < 55) {
      risks.push({
        level: "high", category: "grades",
        message: `Низкий % по: ${cog.courseName.slice(0, 50)}`,
        detail: `${cog.percent}% — риск тройки`,
      });
    } else if (cog.grade === null) {
      risks.push({
        level: "medium", category: "grades",
        message: `Нет итоговой оценки: ${cog.courseName.slice(0, 50)}`,
      });
    }
  }

  // 3. ЗАЧЁТНАЯ КНИЖКА — неcданные дисциплины текущего семестра
  const currentSemesterEntries = gradeBook.filter(e => e.semester === 6);
  for (const e of currentSemesterEntries) {
    if (e.grade === null || e.gradeDate === null) {
      risks.push({
        level: "medium", category: "grades",
        message: `Не сдано: ${e.discipline.slice(0, 50)}`,
        detail: `${e.sectionLabel} | ${e.controlForm}`,
      });
    }
  }

  // 4. ТРОЙКИ В ТЕКУЩЕМ СЕМЕСТРЕ
  const threes = currentSemesterEntries.filter(e => e.grade === 3);
  if (threes.length >= 3) {
    risks.push({
      level: "medium", category: "grades",
      message: `${threes.length} тройки в текущем семестре`,
      detail: threes.map(e => e.discipline.slice(0, 25)).join(", "),
    });
  }

  // 5. НЕСДАННЫЕ ЗАДАНИЯ
  if (missingAssignments.length > 0) {
    const worst = missingAssignments.sort((a, b) => b.daysOverdue - a.daysOverdue)[0];
    risks.push({
      level: missingAssignments.length >= 3 ? "high" : "medium",
      category: "assignments",
      message: `${missingAssignments.length} просроченных заданий`,
      detail: `Давнее: ${worst.name.slice(0, 40)} (${worst.daysOverdue} дней)`,
    });
  }

  // 6. ПРАКТИКИ — тройки и несданные
  const practiceEntries = gradeBook.filter(e => e.sectionLabel === "Практика");
  const badPractice = practiceEntries.filter(e => e.grade !== null && e.grade <= 3);
  if (badPractice.length > 0) {
    risks.push({
      level: "low", category: "practice",
      message: `${badPractice.length} практик с оценкой 3`,
      detail: badPractice.map(e => e.discipline.slice(0, 30)).join(", "),
    });
  }

  // Сортируем: critical → high → medium → low
  const ORDER: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
  return risks.sort((a, b) => ORDER[a.level] - ORDER[b.level]);
}

// ─── Основная синхронизация ───────────────────────────────────────────────────

export async function syncMoodle(
  username: string,
  password: string
): Promise<MoodleSyncResult> {
  // 1. Вход
  let cookie: string;
  try {
    cookie = await loginViaWebForm(username, password);
  } catch (e: any) {
    if (e.message === "invalid_credentials") throw new Error("Неверный логин или пароль");
    throw new Error(e?.message ?? "Не удалось войти в Moodle");
  }

  const errors: string[] = [];

  // 2. sesskey + текущие курсы (параллельно)
  let sesskey = "";
  let courses: MoodleCourse[] = [];
  try {
    sesskey = await getSesskey(cookie);
    if (sesskey) courses = await fetchCourses(cookie, sesskey);
  } catch (e: any) {
    errors.push(`Курсы: ${e?.message ?? e}`);
  }

  // 3. Зачётная книжка + обзор оценок + пропуски + календарь (параллельно)
  const [marksRes, overviewRes, missedRes, calRes] = await Promise.allSettled([
    fetchPage(`${MOODLE_BASE_URL}/blocks/lkstudents/marks.php`, cookie),
    fetchPage(`${MOODLE_BASE_URL}/grade/report/overview/index.php`, cookie),
    fetchPage(`${MOODLE_BASE_URL}/blocks/lkstudents/missedclass.php`, cookie),
    fetchPage(`${MOODLE_BASE_URL}/calendar/view.php?view=upcoming`, cookie),
  ]);

  let gradeBook: GradeBookEntry[] = [];
  if (marksRes.status === "fulfilled") {
    try { gradeBook = parseGradeBookHtml(marksRes.value); }
    catch (e: any) { errors.push(`Зачётная книжка: ${e?.message ?? e}`); }
  } else {
    errors.push(`Зачётная книжка: ${marksRes.reason}`);
  }

  let courseOverview: CourseOverviewGrade[] = [];
  if (overviewRes.status === "fulfilled") {
    try { courseOverview = parseGradeOverview(overviewRes.value); }
    catch (e: any) { errors.push(`Обзор оценок: ${e?.message ?? e}`); }
  }

  let missedHours: Record<string, number> = {};
  if (missedRes.status === "fulfilled") {
    try {
      missedHours = parseMissedHoursHtml(missedRes.value);
      if (Object.keys(missedHours).length === 0) errors.push("Пропуски: нет данных");
    } catch (e: any) { errors.push(`Пропуски: ${e?.message ?? e}`); }
  }

  let calendarEvents: CalendarEvent[] = [];
  const allTasks: Task[] = [];
  if (calRes.status === "fulfilled") {
    try {
      const { tasks: calTasks, events } = parseCalendarHtml(calRes.value);
      calendarEvents = events;
      allTasks.push(...calTasks);
    } catch (e: any) { errors.push(`Календарь: ${e?.message ?? e}`); }
  }

  // 4. Задания по текущим курсам (параллельно, до 10 курсов)
  const allMissing: MissingAssignment[] = [];
  await Promise.allSettled(
    courses.slice(0, 10).map(async (course) => {
      try {
        const html = await fetchPage(
          `${MOODLE_BASE_URL}/mod/assign/index.php?id=${course.id}`, cookie
        );
        const { tasks, missing } = parseAssignments(html, course.id, course.name);
        const seenKeys = new Set(allTasks.map(t => `${t.title}|${t.date.slice(0, 10)}`));
        for (const t of tasks) {
          const key = `${t.title}|${t.date.slice(0, 10)}`;
          if (!seenKeys.has(key)) { seenKeys.add(key); allTasks.push(t); }
        }
        allMissing.push(...missing);
      } catch { /* из кэша */ }
    })
  );

  // 5. Вычисляем риски
  const risks = computeRisks(gradeBook, courseOverview, missedHours, allMissing);

  return {
    tasks: allTasks,
    missedHours,
    gradeBook,
    courseOverview,
    missingAssignments: allMissing,
    calendarEvents,
    courses,
    risks,
    method: "scraping",
    apiError: errors.length > 0 ? errors.join(" | ") : undefined,
  };
}

// ─── Совместимость со старым кодом ────────────────────────────────────────────
// Старое поле grades больше не в MoodleSyncResult, теперь gradeBook.
// Для экранов использующих старый тип — генерируем из gradeBook.
export function gradeBookToLegacyGrades(gradeBook: GradeBookEntry[]) {
  return gradeBook.map(e => ({
    courseId: e.semester,
    courseName: e.sectionLabel,
    itemName: e.discipline,
    grade: e.grade,
    gradeMax: e.controlForm.includes("Экзамен") ? 5 : 5,
  }));
}

// ─── Изменения в расписании ───────────────────────────────────────────────────

export function detectScheduleChanges(
  prev: CalendarEvent[], curr: CalendarEvent[]
): { added: CalendarEvent[]; removed: CalendarEvent[] } {
  const prevIds = new Set(prev.map(e => e.id));
  const currIds = new Set(curr.map(e => e.id));
  return {
    added: curr.filter(e => !prevIds.has(e.id)),
    removed: prev.filter(e => !currIds.has(e.id)),
  };
}
